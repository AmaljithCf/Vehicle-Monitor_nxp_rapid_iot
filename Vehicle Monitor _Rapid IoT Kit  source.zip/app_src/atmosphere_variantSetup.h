#ifndef _ATMOSPHERE_VARIANTSETUP_H_
#define _ATMOSPHERE_VARIANTSETUP_H_

void ATMO_PLATFORM_VariantSetup();

#endif